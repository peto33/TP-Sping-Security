package org.Calculatrice.service;

import org.Calculatrice.controller.Calcul;
import org.springframework.stereotype.Service;

@Service
public class SoustractionService {

    public double calcul(Calcul calcul) {

        double result = calcul.getChiffre1() - calcul.getChiffre2();

        if (result % 9 == 0)
            return result*3;
        else
            return result;

    }
}
