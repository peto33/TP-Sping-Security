package org.Calculatrice.service;

import org.Calculatrice.controller.Calcul;
import org.springframework.stereotype.Service;

@Service
public class DivisionService {

    public double calcul(Calcul calcul) {
        double result = calcul.getChiffre1() / calcul.getChiffre2();
        return result;
    }

}
