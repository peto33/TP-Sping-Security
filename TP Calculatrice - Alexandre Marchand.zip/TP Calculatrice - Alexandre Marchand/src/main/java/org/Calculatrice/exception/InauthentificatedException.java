package org.Calculatrice.exception;

public class InauthentificatedException extends RuntimeException {

    public InauthentificatedException(String msg){
        super(msg);
    }
}
