package org.Calculatrice;

import org.Calculatrice.controller.Calcul;
import org.Calculatrice.service.DivisionService;
import org.Calculatrice.service.MultiplicationService;
import org.Calculatrice.service.SoustractionService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.Calculatrice.service.AdditionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.net.URI;
import java.net.URISyntaxException;

import static org.junit.Assert.assertEquals;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class TestCalculController {

    @Autowired
    private AdditionService additionService;
    @Autowired
    private SoustractionService soustractionService;
    @Autowired
    private DivisionService divisionService;
    @Autowired
    private MultiplicationService multiplicationService;

    private TestRestTemplate restTemplate = new TestRestTemplate();

    @Test
    public void addition(){
        Calcul calcul = new Calcul(3,2,null);
        assertEquals(5, additionService.calcul(calcul), 1e-8);
    }

    @Test
    public void additionMultipleDe4(){
        Calcul calcul = new Calcul(2,2,null);
        assertEquals(2, additionService.calcul(calcul), 1e-8);
    }

    @Test
    public void soustraction() {
        Calcul calcul = new Calcul(2,2,null);
        assertEquals(0, soustractionService.calcul(calcul), 1e-8);

    }

    @Test
    public void soustractionMultipleDe9() {
        Calcul calcul = new Calcul(9,0,null);
        assertEquals(27, soustractionService.calcul(calcul), 1e-8);

    }

    @Test
    public void division() {
        Calcul calcul2 = new Calcul(2,2,null);
        assertEquals(1, divisionService.calcul(calcul2), 1e-8);

    }

    @Test
    public void multiplication() {
        Calcul calcul3 = new Calcul(2,2,null);
        assertEquals(4, multiplicationService.calcul(calcul3), 1e-8);

    }

    @Test
    public void addition403() throws URISyntaxException {
        final String baseUrl = "http://localhost:8080/+/";
        URI uri = new URI(baseUrl);
        Calcul calcul = new Calcul(1000, 1, null);

        HttpHeaders headers = new HttpHeaders();

        HttpEntity<Calcul> request = new HttpEntity<>(calcul, headers);

        ResponseEntity<String> result = this.restTemplate.postForEntity(uri, request,String.class);

        Assert.assertEquals(403, result.getStatusCodeValue());
    }

    @Test
    public void additionPwd() throws URISyntaxException {
        final String baseUrl = "http://localhost:8080/+/";
        URI uri = new URI(baseUrl);
        Calcul calcul = new Calcul(1000, 1, "pwd");

        HttpHeaders headers = new HttpHeaders();

        HttpEntity<Calcul> request = new HttpEntity<>(calcul, headers);

        ResponseEntity<String> result = this.restTemplate.postForEntity(uri, request,String.class);

        Assert.assertEquals(200, result.getStatusCodeValue());
    }

    @Test
    public void resultEgal0() throws URISyntaxException {
        final String baseUrl = "http://localhost:8080/+/";
        URI uri = new URI(baseUrl);
        Calcul calcul = new Calcul(0, 0, null);

        HttpHeaders headers = new HttpHeaders();

        HttpEntity<Calcul> request = new HttpEntity<>(calcul, headers);

        ResponseEntity<String> result = this.restTemplate.postForEntity(uri, request,String.class);

        Assert.assertEquals(404, result.getStatusCodeValue());
    }

    @Test
    public void DivisionResteDifferentDe0() throws URISyntaxException {
        final String baseUrl = "http://localhost:8080///";
        URI uri = new URI(baseUrl);
        Calcul calcul = new Calcul(2, 3, null);

        HttpHeaders headers = new HttpHeaders();

        HttpEntity<Calcul> request = new HttpEntity<>(calcul, headers);

        ResponseEntity<String> result = this.restTemplate.postForEntity(uri, request,String.class);

        Assert.assertEquals(400, result.getStatusCodeValue());
    }

    @Test
    public void DivisionPar0() throws URISyntaxException {
        final String baseUrl = "http://localhost:8080///";
        URI uri = new URI(baseUrl);
        Calcul calcul = new Calcul(2, 0, null);

        HttpHeaders headers = new HttpHeaders();

        HttpEntity<Calcul> request = new HttpEntity<>(calcul, headers);

        ResponseEntity<String> result = this.restTemplate.postForEntity(uri, request,String.class);

        Assert.assertEquals(204, result.getStatusCodeValue());
    }

}
