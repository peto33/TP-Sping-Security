package org.Calculatrice.controller;

import org.Calculatrice.service.AdditionService;
import org.Calculatrice.service.DivisionService;
import org.Calculatrice.service.MultiplicationService;
import org.Calculatrice.service.SoustractionService;
import org.junit.Test;
import org.junit.platform.commons.function.Try;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping
public class CalculController {

    private final String pwd = "pwd";

    @Autowired
    private AdditionService additionService;
    @Autowired
    private SoustractionService soustractionService;
    @Autowired
    private DivisionService divisionService;
    @Autowired
    private MultiplicationService multiplicationService;



    @PostMapping("+")
    public ResponseEntity<Double> addition(@RequestBody Calcul calcul) {


        double result = this.additionService.calcul(calcul);

        if (result < -1000 || result > 1000) {
                if (StringUtils.isEmpty(calcul.getPassword()))
                    return new ResponseEntity<>(HttpStatus.FORBIDDEN);
                else if (calcul.getPassword().equals(pwd))
                    return ResponseEntity.ok(result);
                else
                    return new ResponseEntity<>(HttpStatus.FORBIDDEN);

            } else if (result == 0) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            } else
                return ResponseEntity.ok(result);
    }


    @PostMapping("-")
    public ResponseEntity<Double> soustraction(@RequestBody Calcul calcul) {
        double result = this.soustractionService.calcul(calcul);
        if (result < -1000 || result > 1000) {
            if (StringUtils.isEmpty(calcul.getPassword()))
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
            else if (calcul.getPassword().equals(pwd))
                return ResponseEntity.ok(result);
            else
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        } else if (result == 0) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } else
            return ResponseEntity.ok(result);

    }

    @PostMapping("/")
    public ResponseEntity<Double> division(@RequestBody Calcul calcul) {

        if (calcul.getChiffre2() == 0) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        if (calcul.getChiffre1() % calcul.getChiffre2() != 0) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        double result = this.divisionService.calcul(calcul);

        if (result < -1000 || result > 1000) {
            if (StringUtils.isEmpty(calcul.getPassword()))
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
            else if (calcul.getPassword().equals(pwd))
                return ResponseEntity.ok(result);
            else
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        } else if (result == 0) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } else
            return ResponseEntity.ok(result);
    }

    @PostMapping("*")
    public ResponseEntity<Double> multiplication(@RequestBody Calcul calcul) {
        double result = this.multiplicationService.calcul(calcul);
        if (result < -1000 || result > 1000) {
          if (StringUtils.isEmpty(calcul.getPassword()))
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
          else if (calcul.getPassword().equals(pwd))
              return ResponseEntity.ok(result);
          else
              return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        } else if (result == 0) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } else
            return ResponseEntity.ok(result);
    }


}