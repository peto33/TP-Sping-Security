package org.Calculatrice.controller;

public class Calcul {

    private double chiffre1;
    private double chiffre2;
    private String password;

    public Calcul() { }

    public Calcul(double chiffre1, double chiffre2, String password) {
        this.chiffre1 = chiffre1;
        this.chiffre2 = chiffre2;
        this.password = password;

    }

    public double getChiffre1() {
        return chiffre1;
    }

    public void setChiffre1(double chiffre1) {
        this.chiffre1 = chiffre1;
    }

    public double getChiffre2() {
        return chiffre2;
    }

    public void setChiffre2(double chiffre2) {
        this.chiffre2 = chiffre2;
    }

    public void setPassword(String password){
        this.password = password;
    }

    public String getPassword() {
        return password;
    }
}
